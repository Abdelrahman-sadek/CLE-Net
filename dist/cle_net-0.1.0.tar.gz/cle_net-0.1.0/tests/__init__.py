"""
CLE-Net Test Suite

This package contains comprehensive tests for CLE-Net components.
"""

__version__ = "0.1.0"
