"""
CLE-Net Core Package

Decentralized Cognitive Agent Network - Core Components
"""

__version__ = "0.1.0"
__author__ = "CLE-Net Contributors"
